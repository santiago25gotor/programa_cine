# main.py
from interfaz_consola import GestorCineConsola

if __name__ == "__main__":
    app = GestorCineConsola()
    app.iniciar()
